#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 14:11:00 2020

@author: jeevesh
"""
import os
import numpy as np
import pandas as pd
from scipy.spatial import distance
from random import seed
from random import randint
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer



class Cluster: 
    def __init__(self):
        self.i=0
        self.cluster_idx=[]
       
        

    
    def cluster(self,path):
        c=self.kmeans(path)
        return c
        
        

            
   
    
    def kmeans(self,path):
        
        #print("hi i am start executing")
        files = []
        for r, d, f in os.walk(path):
            for file in f:
                if '.txt' in file:
                    files.append(os.path.join(r, file))
                    
        file_idx=[]
        for i in files:
            file_idx.append(os.path.basename(i))
        
        for i in file_idx:
            self.cluster_idx.append(i[-5])
            
        fullofwords=[]
        for file in files:
            fptr=open(file,'rb')
            filedata=fptr.read().decode('utf-8','ignore')
            fullofwords.append(filedata)
            
            
        
        vectorizer = TfidfVectorizer(stop_words = 'english', lowercase = 'true')
        X = vectorizer.fit_transform(fullofwords)  
        
        feature_matrix = X.toarray()
        centroid_with_each_cluster=[]
        
        starting_values=[]
        for i in file_idx:
            starting_values.append(int(i[-5]))
    
    
        
        
        centroid_with_each_cluster=[]
        random_number=[]
        seed(1)
        for _ in range(5):
            value = randint(0, 1725)
            random_number.append(value)
        
        for i in random_number:
            centroid_with_each_cluster.append(feature_matrix[i])    
    
    
        iterations = 100
        for i in range(0,iterations):
            temp_container=[[],[],[],[],[],[]]
            for j in range(0,len(feature_matrix)):
                min_value=999999
                cluster_value=0
                for cluster_index in range(len(centroid_with_each_cluster)):
                    dist=np.linalg.norm(centroid_with_each_cluster[cluster_index]-feature_matrix[j])
                    if(dist<min_value):
                        min_value = dist
                        cluster_value=cluster_index+1
    
                    temp_container[cluster_value].append(feature_matrix[j])
                    self.cluster_idx[j]=cluster_value
            for idx in range(len(centroid_with_each_cluster)):
                centroid_with_each_cluster[idx] = (np.mean(temp_container[idx+1],axis=0)) 
        #print("cluster_idx")   
        #print(self.cluster_idx)
        #print(len(self.cluster_idx))
        #print("end")
        
        return self.cluster_idx 
    
        