#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 19:39:10 2020

@author: jeevesh
"""

import numpy as np
import pandas as pd
from scipy.spatial import distance
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
import seaborn as sns



class Airfoil:
    def __init__(self):
        self.Q_got = None
        
        
        
        
    
        
        
    def linear_regression(self,iterations,learningRate,Q_new,m,data_without_label,train_label):
        for i in range(iterations):
            predicted = data_without_label.dot(Q_new)
            error = predicted - train_label
            self.Q_got = np.dot(data_without_label.T,error)
            Q_new = Q_new - (1/m)*learningRate*self.Q_got
        return Q_new
        
    
    
    def train(self,training_path):
        
        training_data = pd.read_csv(training_path)
        training_data=training_data.to_numpy()
        train_label = training_data[:,[5]]
        data_without_label = training_data[:,0:5].copy()
        scaler = MinMaxScaler()
        data_without_label=scaler.fit_transform(data_without_label)
        data_without_label=np.append(np.ones((len(data_without_label),1)),data_without_label,axis=1)
        self.Q_got=np.random.rand(6,1)
        self.Q_got= self.linear_regression(100000,.1,self.Q_got,len(data_without_label),data_without_label,train_label)
        
        
        
        
        
    def predict(self,predicting_path):
        predicting_data = pd.read_csv(predicting_path)
        predicting_data=predicting_data.to_numpy()
        scaler = MinMaxScaler()
        predicting_data=scaler.fit_transform(predicting_data)
        predicting_data=np.append(np.ones((len(predicting_data),1)),predicting_data,axis=1)
        
        prediction = predicting_data.dot(self.Q_got)
        return prediction
