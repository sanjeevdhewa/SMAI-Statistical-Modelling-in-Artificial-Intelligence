#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 18:18:43 2020

@author: jeevesh
"""


import numpy as np
import pandas as pd
from scipy.spatial import distance
from collections import Counter
from sklearn.model_selection import train_test_split





class Weather:
    def __init__(self):
        