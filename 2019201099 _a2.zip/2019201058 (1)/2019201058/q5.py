#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 16:54:18 2020

@author: jeevesh
"""

import numpy as np
import pandas as pd
from scipy.spatial import distance
from sklearn.metrics import r2_score
import numpy as np
import pandas as pd
from scipy.spatial import distance
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn import svm
from sklearn.metrics import accuracy_score


class AuthorClassifier:
    def __init__(self):
        self.data_without_label_vectorise=None
        self.test_vectorise=None
        self.label=         None
        
    
    
    
    
    
    def svm_linear(self,X_train, y_train,X_test):
        clf = svm.SVC(probability=False ,kernel='linear',C=0.1,gamma = 'auto')
        clf.fit(X_train, y_train)
        y_pred = clf.predict(X_test)
        #print(accuracy_score(y_test, y_pred))
        return y_pred
        
    
    
    
    def train(self,training_path):
        training_data = pd.read_csv(training_path)
        training_data=training_data.drop(training_data.columns[0],axis=1)
        data  = training_data['text']
        self.label = training_data['author']
        data=data.to_numpy()
        vectorizer = CountVectorizer()
        self.data_without_label_vectorise = vectorizer.fit_transform(data.ravel())
        self.data_without_label_vectorise = self.data_without_label_vectorise.toarray()
        
        
    
        
        
    def predict(self,predicting_path):
        predicting_data = pd.read_csv(predicting_path)
        predicting_data=predicting_data.drop(predicting_data.columns[0],axis=1)
        vectorizer = CountVectorizer()
        predicting_data = predicting_data.to_numpy()
        self.test_vectorise = vectorizer.fit_transform(predicting_data.ravel())
        self.test_vectorise = self.test_vectorise.toarray()
        return self.svm_linear(self.data_without_label_vectorise, self.label,self.test_vectorise)
        