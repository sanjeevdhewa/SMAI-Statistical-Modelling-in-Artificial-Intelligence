import numpy as np
import pandas as pd
from scipy.spatial import distance
from collections import Counter
#from sklearn.model_selection import train_test_split


class KNNClassifier:
  k=3
  def __init__(self):
    self.correct_label=[]
    self.result_data=[]
    self.local_k=[]
    self.corrcet=0
    self.wrong=0
    self.train_data=pd.DataFrame()
    self.test_data=pd.DataFrame()

        
        
        
      
        
  def train(self,training_data):
    self.train_data = pd.read_csv(training_data,header=None)
    self.train_data = pd.DataFrame(self.train_data).to_numpy()
  
  def predict(self,testing_data):
    self.test_data = pd.read_csv(testing_data,header=None)
    self.test_data = pd.DataFrame(self.test_data).to_numpy()
    result_data=[]
    for j in range(len(self.test_data)):
      #print(j)
      local_k=[]
      for i in range(len(self.train_data)):
        distance = np.linalg.norm(self.train_data[i][1:] - self.test_data[j])
        local_k.append((distance,self.train_data[i][0]))
        local_k.sort()
        if len(local_k) > self.k:
          local_k.pop()
      count_labels=[]
      for i in range(len(local_k)):
        count_labels.append(local_k[i][1])
      result_data.append(self.most_frequent(count_labels))        
    return result_data   
        
        
        
  def most_frequent(self,List):
    occurence_count = Counter(List) 
    return occurence_count.most_common(1)[0][0]      
