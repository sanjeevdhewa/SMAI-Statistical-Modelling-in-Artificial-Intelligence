"""
Created on Tue Mar 31 17:06:13 2020

@author: jeevesh
"""

import sys
import numpy as np
import pandas as pd
from scipy.linalg import eigh
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn import metrics
import cv2
import os
import glob




def one_hot(input_label):
    
    label_vector = list(np.unique(input_label))
    encoded_matrix = np.zeros([len(input_label),len(label_vector)])
    for i,c in enumerate(input_label):
        encoded_matrix[i][label_vector.index(c)] = 1
    return encoded_matrix

def fit(reduced_matrix,class_label,learning_rate,iterations):
    
    reduced_matrix = np.insert(reduced_matrix,0,1,axis=1)
    unique_label=np.unique(class_label)
    weight_matrix_new = np.zeros([ unique_label.shape[0],reduced_matrix.shape[1]], dtype=np.float128)
    vector_label = one_hot(class_label)
    # vector_label = y
    
    for i in range(iterations):
        
        score_matrix = np.dot(reduced_matrix,weight_matrix_new.T)
        softmax_return  = np.exp(score_matrix) / (np.sum(np.exp(score_matrix),axis=1).reshape(-1,1))
        error_difference = softmax_return - vector_label
        gradient = np.dot(error_difference.T,reduced_matrix)
        weight_matrix_new = weight_matrix_new - learning_rate*gradient
    return weight_matrix_new



def find_probability(input_matrix,weight_matrix_updated):
    print("in find_probability")
    print("find_probability",input_matrix.shape)
    score_matrix = np.dot(input_matrix,weight_matrix_updated.T)
    softmax_return  = np.exp(score_matrix) / (np.sum(np.exp(score_matrix),axis=1).reshape(-1,1))
    return softmax_return
    

def accuracy_check(input_matrix,class_label,weight_matrix_updated):
    print("accuracy_finction",input_matrix.shape)
    input_matrix = np.insert(input_matrix,0,1,axis=1)
    print("accuracy_finction",input_matrix.shape)
    unique_label=np.unique(class_label)
    return np.vectorize(lambda i:unique_label[i])(np.argmax(find_probability(input_matrix,weight_matrix_updated),axis=1))
    

def score_calculator(input_matrix,class_label,weight_matrix_updated):
    print("in score_calculator")

    return np.mean(accuracy_check(input_matrix,class_label,weight_matrix_updated) == class_label)

def pca(input_matrix,no_of_component):
    
    #print(input_matrix.shape)
    
    input_matrix = (input_matrix - input_matrix.mean(axis=0))# for row
    np.set_printoptions(precision=3)
    covarianceMatrix_part2 = np.cov(input_matrix.transpose())
    EigVal_part2,EigVec_part2 = eigh(covarianceMatrix_part2)
    order_part2 = EigVal_part2.argsort()[::-1]
    EigVal_part2 = EigVal_part2[order_part2]
    EigVec_part2 = EigVec_part2[:,order_part2]
    newcreated_input_matrix = EigVec_part2[:,0:no_of_component]
    recreated_matrix=np.dot(input_matrix,newcreated_input_matrix)
    return recreated_matrix


def input_Function(data_part2,image_resize,pca_components):

    
    # do Resizing
    dim = image_resize
    height = dim
    width = dim
    dim_hw = (width, height)
    
    res_img_part2 = []
    for i in range(len(data_part2)):
        resize_part2 = cv2.resize(data_part2[i], dim_hw, interpolation=cv2.INTER_LINEAR)
        res_img_part2.append(resize_part2)
        
    res_img_part2= np.asarray(res_img_part2)

    grayarray_part2=res_img_part2.copy()
    flattenedarray_part2=[]
    newdata_part2=[]
    
    for i in range(len(grayarray_part2)):
        temp = grayarray_part2[i].flatten()
        newdata_part2.append(temp)
        flattenedarray_part2.append(temp)
    
    flattenedarray_part2 = np.asarray(flattenedarray_part2)
    newdata_part2        = np.asarray(newdata_part2)
    reduced_matrix = pca(flattenedarray_part2,pca_components)
    reduced_matrix=(reduced_matrix-reduced_matrix.mean())/reduced_matrix.std()
    return reduced_matrix


def training_function(input_path,learning_rate,iteration,image_resize,pca_components):
    
    
    #function to read file
    total_files_part2=[]
    train_path = input_path
    f = open(train_path, "r")
    for x in f:
        path,name = x.split()
        total_files_part2.append(path)
        data_part2 = []
        path_name[int(path[-11:-8])]=name
    for ind in total_files_part2:
        img = cv2.imread(ind,0)
#         print(img)
        data_part2.append(img)
    f.close()
    
    
    
    
    reduced_matrix = input_Function(data_part2,image_resize,pca_components)

    class_label=[]
    for i in total_files_part2:
        class_label.append(int(i[-11:-8]))
    

        
    unique_label=np.unique(class_label)
        
    weight_matrix_updated = fit(reduced_matrix,class_label,learning_rate,iteration)
    #.01,400
    
    return weight_matrix_updated
    
    
    
def testing(input_path,weight_matrix_updated,image_resize,pca_components):
    
 
    
    total_files_part2=[]
    data_part2 = []
    test_path = input_path
    f = open(test_path, "r")
    
    for x in f:
        path = x.strip()
        total_files_part2.append(path)
    for ind in total_files_part2:
        img = cv2.imread(ind,0)
        data_part2.append(img)
    f.close()
    

    
    
    input_matrix = input_Function(data_part2,image_resize,pca_components)
    input_matrix = np.insert(input_matrix,0,1,axis=1)
    score_matrix = np.dot(input_matrix,weight_matrix_updated.T)
    softmax_return  = np.exp(score_matrix) / (np.sum(np.exp(score_matrix),axis=1).reshape(-1,1))
    predicted_values = np.argmax(softmax_return, axis=1)

    
    
    f = open("./demo_result.txt", "w")
    for i in predicted_values:
        print(path_name[i])
    
        f.write(path_name[i])
        f.write("\n")
    f.close()
    
    
    return predicted_values




# input_path="/home/jeevesh/Desktop/smai/assignment3/OneDrive_1_24-03-2020/sample_train.txt"
#input_path="./sample_train.txt"
#test_path1="./sample_test.txt"
path_name={}
input_path=sys.argv[1]
test_path1=sys.argv[2]
training_output = training_function(input_path,.01,350,128,40)
testing_return=testing(test_path1,training_output,128,40)
 
    
    
    
    
    
    
    
    

    
    
    
    
