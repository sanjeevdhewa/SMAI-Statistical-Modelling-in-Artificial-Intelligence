#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr  3 18:53:12 2020

@author: jeevesh
"""

import numpy as np
import sys
import pandas as pd
from numpy import nan
from numpy import isnan
from numpy import array
from statistics import mean
from scipy.spatial import distance
from collections import Counter
from sklearn.model_selection import train_test_split
from sklearn import datasets, linear_model
from sklearn.metrics import mean_squared_error, r2_score


def preProcessing(training_data):
  question_mark_list=[]
  original_data=[]
  for i in range(training_data.shape[0]):
    if (training_data[i]=='?'):
      question_mark_list.append(i)
      original_data.append((training_data[i]))
      continue
    original_data.append(float(training_data[i]))
  
  training_data=training_data.drop(training_data.index[question_mark_list])


  return original_data,question_mark_list,training_data

def split_sequence(sequence, n_steps):
    
	X, y = list(), list()
	for i in range(len(sequence)):
		# find the end of this pattern
		end_ix = i + n_steps
		# check if we are beyond the sequence
		if end_ix > len(sequence)-1:
			break
		# gather input and output parts of the pattern
		seq_x, seq_y = sequence[i:end_ix], sequence[end_ix]
		X.append(seq_x)
		y.append(seq_y)
	return array(X), array(y)

def predict(question_mark_list,original_data):
    
    
    output_values=[]
    for i in range(len(question_mark_list)):
        if(question_mark_list[i]>=0 and question_mark_list[i]<= 60):
            min_window=0
            max_window=question_mark_list[i]
            y_pred = mean(original_data[min_window:max_window])
            original_data[i]=y_pred
            output_values.append(y_pred) 
        else:
            max_window=question_mark_list[i]
            min_window=question_mark_list[i]-60
            y = np.array(original_data[min_window:max_window])
            y=y.reshape(-1,60)
            y_pred = regr.predict(y)
            original_data[question_mark_list[i]]=y_pred
            output_values.append(y_pred)
  
    return output_values
    
    # print("i:",question_mark_list[i])
    # print("y_pred:",y_pred)
    

#path = '/content/drive/My Drive/smai_assignment3/power.txt'
path = sys.argv[1]
training_data = pd.read_csv(path, sep=';', header=0, low_memory=False, infer_datetime_format=True, parse_dates={'datetime':[0,1]}, index_col=['datetime'])
training_data=training_data['Global_reactive_power']
original_data=training_data.copy()
original_data,question_mark_list,training_data=preProcessing(training_data)
column_size=60
data , label = split_sequence(training_data,column_size)
regr = linear_model.LinearRegression()
regr.fit(data, label)
output_values=predict(question_mark_list,original_data)
for i in output_values:
  print(i)


