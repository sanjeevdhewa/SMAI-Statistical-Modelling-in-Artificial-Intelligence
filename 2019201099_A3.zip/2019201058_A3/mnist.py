#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr  3 10:41:32 2020

@author: jeevesh
"""
import sys
import idx2numpy
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import seaborn as sns
import numpy as np
import pandas as pd
from numpy import nan
from numpy import isnan
from numpy import array
from scipy.spatial import distance
from collections import Counter
from sklearn.model_selection import train_test_split

np.random.seed(2)

from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
import itertools

from keras.utils.np_utils import to_categorical # convert to one-hot-encoding
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten, Conv2D, MaxPool2D
from keras.optimizers import RMSprop
from keras.preprocessing.image import ImageDataGenerator
from keras.callbacks import ReduceLROnPlateau



def take_data(data_files_path):
  train_data_path=data_files_path+'train-images-idx3-ubyte'
  train_labels_path=data_files_path+'train-labels-idx1-ubyte'
  test_data_path=data_files_path+'t10k-images-idx3-ubyte'

  Train_D=idx2numpy.convert_from_file(train_data_path)
  Train_Data=np.zeros((Train_D.shape[0],(Train_D.shape[1]**2)))
  for i in range(Train_Data.shape[0]):
    temp=Train_D[i,:,:].flatten()
    Train_Data[i,:]=temp


  Test_D=idx2numpy.convert_from_file(test_data_path)
  Test_Data=np.zeros((Test_D.shape[0],(Test_D.shape[1]**2)))
  for i in range(Test_Data.shape[0]):
    temp=Test_D[i,:,:].flatten()
    Test_Data[i,:]=temp

  train_label=idx2numpy.convert_from_file(train_labels_path)


  return Train_Data,train_label,Test_Data


  # test_labels=data_files_path+'t10k-labels-idx1-ubyte'


def normalizeAndReshaping(train_data_part3,test_data_part3):
  train_data_part3=train_data_part3/255
  test_data_part3=test_data_part3/255

  train_data_part3 = np.reshape(train_data_part3, (-1,28,28,1))
  test_data_part3 = np.reshape(test_data_part3, (-1,28,28,1))

  return train_data_part3,test_data_part3



def convertLabelToCategorical(train_label_part3):
  train_label_part3 = to_categorical(train_label_part3, num_classes = 10)

  return train_label_part3
  

def model_create():


  model = Sequential()

  model.add(Conv2D(filters = 32, kernel_size = (5,5),padding = 'Same', 
                 activation ='relu', input_shape = (28,28,1)))
  model.add(Conv2D(filters = 32, kernel_size = (5,5),padding = 'Same', 
                 activation ='relu'))
  model.add(MaxPool2D(pool_size=(2,2)))
  model.add(Dropout(0.25))


  model.add(Conv2D(filters = 64, kernel_size = (3,3),padding = 'Same', 
                 activation ='relu'))
  model.add(Conv2D(filters = 64, kernel_size = (3,3),padding = 'Same', 
                 activation ='relu'))
  model.add(MaxPool2D(pool_size=(2,2), strides=(2,2)))
  model.add(Dropout(0.25))
  model.add(Flatten())
  model.add(Dense(256, activation = "relu"))
  model.add(Dropout(0.5))
  model.add(Dense(10, activation = "softmax"))
  return model



def fitTheModelAndPredict(model,train_data_part3,train_label_part3,test_data_part3):

  optimizer = RMSprop(lr=0.001, rho=0.9, epsilon=1e-08, decay=0.0)

  model.compile(optimizer = optimizer , loss = "categorical_crossentropy", metrics=["accuracy"])

  learning_rate_reduction = ReduceLROnPlateau(monitor='val_acc', 
                                            patience=3, 
                                            verbose=1, 
                                            factor=0.5, 
                                            min_lr=0.00001)

  history = model.fit(train_data_part3, train_label_part3, batch_size = 86, epochs = 30, verbose = 0)
  test_label_pred = model.predict(test_data_part3)
  test_label_pred = np.argmax(test_label_pred,axis = 1) 
  return test_label_pred




data_files_path = sys.argv[1] #'/content/drive/My Drive/smai_assignment3/'

train_data_part3,train_label_part3,test_data_part3 = take_data(data_files_path)

train_data_part3,test_data_part3=normalizeAndReshaping(train_data_part3,test_data_part3)

train_label_part3=convertLabelToCategorical(train_label_part3)

model = model_create()

test_label_pred = fitTheModelAndPredict(model,train_data_part3,train_label_part3,test_data_part3)

for i in test_label_pred:
  print(i)

