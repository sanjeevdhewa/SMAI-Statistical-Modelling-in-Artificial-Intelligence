'''

dependency needed:
!pip install nltk
!pip install unidecode


How to run this file?
python3 2019201058.py parameter1 parameter2
parameter1 = path to train.csv 
parameter2 = path to test.csv
return : save submission_2019201058_htspc.csv in current directory

example:
python3 2019201058_htspc.py ./train.csv ./test.csv
'''










#!pip install nltk
#!pip install unidecode
import numpy as np
import pandas as pd
import re
import string
import nltk
import spacy
pd.options.mode.chained_assignment = None
import unicodedata
from unidecode import unidecode
#remove stopwords

# removal of stopwords
from nltk.corpus import stopwords
import nltk
nltk.download('stopwords')
STOPWORDS = set(stopwords.words('english'))
#now do lammetizer
from nltk.stem import WordNetLemmatizer
nltk.download('wordnet')
# function to remove punctuation
from string import punctuation
from string import digits
remove_digits = str.maketrans('', '', digits)
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np
from sklearn.metrics import f1_score
from sklearn.svm import SVC
import sys

lemmatizer = WordNetLemmatizer()




def strip_punctuation(s):
    return ''.join(c for c in s if c not in punctuation)



def deEmojify(inputString):
    returnString = ""

    for character in inputString:
        try:
            character.encode("ascii")
            returnString += character
        except UnicodeEncodeError:
            replaced = unidecode(str(character))
            if replaced != '':
                returnString += replaced
            else:
                try:
                     returnString += "[" + unicodedata.name(character) + "]"
                except ValueError:
                     returnString += "[x]"

    return returnString





def remove_stopwords(text):
    """custom function to remove the stopwords"""
    return " ".join([word for word in str(text).split() if word not in STOPWORDS])




def lemmatize_words(text):
    return " ".join([lemmatizer.lemmatize(word) for word in text.split()])


#function to lower
training_data=pd.read_csv(sys.argv[1])
test_data=pd.read_csv(sys.argv[2])
for i in range(training_data.shape[0]):
    training_data['text'][i] = training_data['text'][i].lower() 
    training_data['text'][i]=strip_punctuation(training_data['text'][i])
    training_data['text'][i] = training_data['text'][i].encode('ascii', 'ignore').decode('ascii')
training_data['text'] = training_data['text'].apply(lambda text: lemmatize_words(text))
for i in range(training_data.shape[0]):  
    training_data['text'][i] = training_data['text'][i].translate(remove_digits)
training_data['text'] = training_data['text'].apply(lambda text: remove_stopwords(text))
feature_extraction = TfidfVectorizer(min_df=1)
vector = feature_extraction.fit_transform(training_data['text'].values)

clf = SVC(kernel='rbf')
clf.fit(vector, training_data['labels'])

for i in range(test_data.shape[0]):
    test_data['text'][i] = test_data['text'][i].lower() 
    test_data['text'][i]=strip_punctuation(test_data['text'][i])
    test_data['text'][i] = test_data['text'][i].encode('ascii', 'ignore').decode('ascii')
test_data['text'] = test_data['text'].apply(lambda text: lemmatize_words(text))
for i in range(test_data.shape[0]):  
    test_data['text'][i] = test_data['text'][i].translate(remove_digits)
test_data['text'] = test_data['text'].apply(lambda text: remove_stopwords(text))

test_features = feature_extraction.transform(test_data['text'].values)

y_pred = clf.predict(test_features)

y_pred=pd.DataFrame(data=y_pred,columns=['labels']);
print(y_pred)
y_pred.to_csv("./submission_2019201058_htspc.csv",index=True)
