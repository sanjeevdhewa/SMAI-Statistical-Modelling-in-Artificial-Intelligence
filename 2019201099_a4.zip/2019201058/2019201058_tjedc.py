#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May  1 21:41:19 2020



1. how to run py file
python3 2019201058_tjedc.py parameter1 parameter2 parameter3 parameter4
parameter1 = absolute location of train.csv
parameter2 = absolute location of train folder as given in test set and validation set "train/ntrain/*images"
(images should be present inside ntrain folder which is present inside train folder as given in test set)
parameter 3 = absolute path of test.csv
parameter 4 = absolute location of test folder as given in test set  "test/test/*images"
(images should be present inside test folder which is present inside test folder as given in test set)
return : save submission_2019201058_tjedc.csv

Exapmle : python3 2019201058_tjedc.py ./train.csv ./train ./test.csv ./test
return :  store submission_2010201058_tjedc.py

Reference :https://blog.keras.io/building-powerful-image-classification-models-using-very-little-data.html
provided in question


@author: jeevesh
"""


import tensorflow as tf
from tensorflow import keras
import numpy as np
import pandas as pd
import cv2
import sys
from sklearn.preprocessing import OneHotEncoder
encode = OneHotEncoder()
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D
from keras.layers import Activation, Dropout, Flatten, Dense



training_data = pd.read_csv(sys.argv[1])
image_path = sys.argv[2]

label = np.array(training_data['emotion'])
label= label.reshape(-1,1)

label=np.array(label)
label=label.reshape(-1,1)

label = encode.fit_transform(label).toarray()

width = 128
height = 128
dim = (width, height)


faceImages=[]
for i in training_data['image_file']:
    idb = image_path + i + ".jpg"
    print(idb)
    img = cv2.imread(idb,0)
    resized = cv2.resize(img, dim, interpolation = cv2.INTER_AREA)
    faceImages.append(resized)
    
x_train = np.array(faceImages)
x_train = x_train.reshape(len(x_train),128, 128,1)


model = Sequential()
model.add(Conv2D(32, (3, 3), input_shape = (128,128,1)))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))

model.add(Conv2D(32, (3, 3)))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))

model.add(Conv2D(64, (3, 3)))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))

model.add(Flatten())
model.add(Dense(64))
model.add(Activation('relu'))
model.add(Dropout(0.25))
model.add(Dense(5, activation='softmax'))
model.compile(loss='categorical_crossentropy', optimizer='adadelta', metrics=['accuracy'])


model.fit(x_train, label, epochs=100, batch_size=64)

#upload test file
test_data = pd.read_csv(sys.argv[3])
test_path = sys.argv[4]

testImages=[]
for i in test_data['image_file']:
    idb = test_path + i + ".jpg"
    print(idb)
    img = cv2.imread(idb,0)
    resized = cv2.resize(img, dim, interpolation = cv2.INTER_AREA)
    testImages.append(resized)
    
x_test = np.array(testImages) 
x_test = x_test.reshape(len(x_test),128, 128,1)

output = model.predict(x_test)


result=[]
for i in range(len(output)):
    result.append(np.argmax(output[i]))
    
    
np.savetxt("./submission_2019201058_tjedc.csv", result,fmt="%d",header ="emotion",comments='', delimiter=",")

    







