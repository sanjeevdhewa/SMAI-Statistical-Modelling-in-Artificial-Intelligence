#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May  1 20:52:18 2020


Dependencies
!wget -c https://repo.continuum.io/miniconda/Miniconda3-latest-Linux-x86_64.sh
!chmod +x Miniconda3-latest-Linux-x86_64.sh
!time bash ./Miniconda3-latest-Linux-x86_64.sh -b -f -p /usr/local
!time conda install -q -y -c conda-forge rdkit
!pip install git+https://github.com/samoturk/mol2vec;


how to run this file:
python3 2019201058_htspc.py parameter1 parameter2
parameter1 = path to train.csv
parameter2 = path to test.csv
return : save submission_2019201058_covid.py in local directory

example: python3 2019201058_covid.py ./train.csv ./test.csv

Reference:https://www.kaggle.com/vladislavkisin/tutorial-ml-in-chemistry-research-rdkit-mol2vec
this link is provided in Question 

@author: jeevesh
"""





import pandas as pd
import numpy as np
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error
import math

import matplotlib.pyplot as plt
import sys
import os
sys.path.append('/usr/local/lib/python3.7/site-packages/')
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")
from rdkit import Chem 
from mol2vec.features import mol2alt_sentence, mol2sentence, MolSentence, DfVec, sentences2vec
from gensim.models import word2vec





training_path=svs.argv[1]
testing_path=sys.argv[2]


#Load the dataset and extract target values
mdf= pd.read_csv(training_path, names=['smiles', 'target'])
test=pd.read_csv(testing_path,names=['smiles', 'target'])
test.drop(0,inplace=True)
mdf.drop(0,inplace=True)
target = mdf['target']
mdf.drop(columns='target',inplace=True)
#Transforming SMILES to MOL
mdf['mol'] = mdf['smiles'].apply(lambda x: Chem.MolFromSmiles(x))
test['mol'] = test['smiles'].apply(lambda x: Chem.MolFromSmiles(x))

model_path = './model_300dim.pkl'

from gensim.models import word2vec
model = word2vec.Word2Vec.load(model_path)
#Constructing sentences
mdf['sentence'] = mdf.apply(lambda x: MolSentence(mol2alt_sentence(x['mol'], 1)), axis=1)
test['sentence']=test.apply(lambda x: MolSentence(mol2alt_sentence(x['mol'], 1)), axis=1)
#Extracting embeddings to a numpy.array
#Note that we always should mark unseen='UNK' in sentence2vec() so that model is taught how to handle unknown substructures
mdf['mol2vec'] = [DfVec(x) for x in sentences2vec(mdf['sentence'], model, unseen='UNK')]
X = np.array([x.vec for x in mdf['mol2vec']])
y = target.values
clf = SVR(kernel='rbf',C=18, epsilon=1.3,gamma=0.001)
clf.fit(X, y)
test['mol2vec'] = [DfVec(x) for x in sentences2vec(test['sentence'], model, unseen='UNK')]
test_features = np.array([x.vec for x in test['mol2vec']])
test_prediction=clf.predict(test_features)
test_prediction=test_prediction.reshape(len(test_prediction),1)
type(test_prediction)
chem_names = test['smiles'] 
chem_names=np.array(chem_names)
chem_names=chem_names.reshape(len(chem_names),1)
final=np.concatenate((chem_names,test_prediction),1)
final_df=pd.DataFrame(final)
pd.set_option("display.precision", 17)
df=pd.DataFrame(final_df)
df=df.rename(columns={0:'SMILES sequence',1: 'Binding Affinity'})
dest_path = './submission_2019201058_covid.csv'
df.to_csv(dest_path,index=False,float_format='%g')











